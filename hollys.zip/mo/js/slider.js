//메인 슬라이더
$('.slider').bxSlider({
  auto:true,
  pause:4000,
});