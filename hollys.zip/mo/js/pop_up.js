// 팝업
$('#close_1day').click(function(){
  $('.pop_win').hide();
})
$('#close').click(function(){
  $('.pop_win').hide();
})